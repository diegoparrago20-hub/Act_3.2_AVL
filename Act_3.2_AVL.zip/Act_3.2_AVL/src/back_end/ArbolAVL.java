/*
 Equipo #2
 CONTRERAS RODRIGUEZ JANIS ISABEL
 LIRA DOMINGUEZ BRYANT 
 PARRA GONZALEZ DIEGO ALBERTO
 */
package back_end;
/**
 *
 * @author coter
 */
public class ArbolAVL {
    private NodoAVL raiz;
    
    public ArbolAVL() {
        this.raiz = null;
    }
    
    public NodoAVL getRaiz() { 
        return raiz; 
    }

//insertar(Empleado empleado): 
    public void insertar(Empleado empleado) { // metodo "Publico"
        if (empleado == null) {
            throw new IllegalArgumentException("ERROR: El empleado no puede ser nulo");
        }
        if (buscar(empleado.getId()) != null) { //si se repite el mismo
            throw new IllegalArgumentException("ERROR: El ID " + empleado.getId() + " ya existe(esta duplicado)");
        }
        raiz = insertarRec(raiz, empleado);
    }
    private NodoAVL insertarRec(NodoAVL nodo, Empleado empleado) {//"Recursiva"
        if (nodo == null) {
            return new NodoAVL(empleado);
        }
        if (empleado.getId() < nodo.getDato().getId()) {
            nodo.setIzquierdo(insertarRec(nodo.getIzquierdo(), empleado));
        } else {
            nodo.setDerecho(insertarRec(nodo.getDerecho(), empleado));
        }
        actualizarAltura(nodo);
        return balancear(nodo);
    }
    
//eliminar(Integer id):
   public void eliminar(Integer id) { // metodo "Publico"
        if (id == null) {
            throw new IllegalArgumentException("ERROR: El ID no puede ser nulo");
        }
        if (raiz == null) {
            throw new IllegalArgumentException("ERROR: El árbol está vacío, no hay empleados que eliminar");
        }
        if (buscar(id) == null) {
            throw new IllegalArgumentException("ERROR: No se encontró empleado con el ID " + id);
        }
        raiz = eliminarRec(raiz, id);
    }
    private NodoAVL eliminarRec(NodoAVL nodo, Integer id) { //"Recursiva"
        if (nodo == null) {
            return null;
        }
        if (id < nodo.getDato().getId()) {
            nodo.setIzquierdo(eliminarRec(nodo.getIzquierdo(), id));
        } else if (id > nodo.getDato().getId()) {
            nodo.setDerecho(eliminarRec(nodo.getDerecho(), id));
        } else {
            if (nodo.getIzquierdo() == null && nodo.getDerecho() == null) {// Caso 1: hoja
                return null;
            }
            if (nodo.getIzquierdo() == null) { // Caso 2: un solo hijo (el derecho)
                return nodo.getDerecho();
            }
            if (nodo.getDerecho() == null) { // Caso 2: un solo hijo (el izquierdo)
                return nodo.getIzquierdo();
            }
            NodoAVL sucesor = minimo(nodo.getDerecho());// Caso 3: dos hijos -> sucesor inorden
            nodo.setDato(sucesor.getDato());
            nodo.setDerecho(eliminarRec(nodo.getDerecho(), sucesor.getDato().getId()));
        }
        actualizarAltura(nodo);
        return balancear(nodo);
    }
    private NodoAVL minimo(NodoAVL nodo) { // Para buscar un sucesor si hay 2 hijos
        while (nodo.getIzquierdo() != null) {
            nodo = nodo.getIzquierdo();
        }
        return nodo;
    }
 
//buscar(Integer id): 
    public Empleado buscar(Integer id) {  // metodo "Publico"
        if (id == null) {
            return null;
        }
        return buscarRec(raiz, id);
    }
    private Empleado buscarRec(NodoAVL nodo, Integer id) { //"Recursiva"
        if (nodo == null) {
            return null;
        }
        if (id.equals(nodo.getDato().getId())) {
            return nodo.getDato();
        }
        if (id < nodo.getDato().getId()) {
            return buscarRec(nodo.getIzquierdo(), id);
        } else {
            return buscarRec(nodo.getDerecho(), id);
        }
    }

//obtenerAltura(NodoAVL nodo) / factorEquilibrio(NodoAVL nodo):     
    public int obtenerAltura(NodoAVL nodo) {
        return (nodo == null) ? 0 : nodo.getAltura();
    }
    public int factorEquilibrio(NodoAVL nodo) {
        if (nodo == null) {
            return 0;
        }
        return obtenerAltura(nodo.getDerecho()) - obtenerAltura(nodo.getIzquierdo());
    }
    private void actualizarAltura(NodoAVL nodo) {
        if (nodo != null) {
            nodo.setAltura(1 + Math.max(obtenerAltura(nodo.getIzquierdo()),
                                        obtenerAltura(nodo.getDerecho())));
        }
    }

//rotacionIzquierda(), rotacionDerecha(), etc.:    
    // Rotación simple a la derecha (caso izquierda-izquierda)
    private NodoAVL rotacionDerecha(NodoAVL y) {
        NodoAVL x = y.getIzquierdo();
        NodoAVL T2 = x.getDerecho();

        x.setDerecho(y);
        y.setIzquierdo(T2);

        actualizarAltura(y);
        actualizarAltura(x);
        return x; // x pasa a ser la nueva raíz
    }
    // Rotación simple a la izquierda (caso derecha-derecha)
    private NodoAVL rotacionIzquierda(NodoAVL x) {
        NodoAVL y = x.getDerecho();
        NodoAVL T2 = y.getIzquierdo();

        y.setIzquierdo(x);
        x.setDerecho(T2);

        actualizarAltura(x);
        actualizarAltura(y);
        return y; // y pasa a ser la nueva raíz
    }   
    // Balanceo automatico
    private NodoAVL balancear(NodoAVL nodo) {
        int fe = factorEquilibrio(nodo);

        // FE = -2: el subárbol izquierdo es más alto
        if (fe < -1) {
            // Doble izquierda-derecha: hijo izquierdo con FE = +1
            if (factorEquilibrio(nodo.getIzquierdo()) > 0) {
                nodo.setIzquierdo(rotacionIzquierda(nodo.getIzquierdo()));
            }
            return rotacionDerecha(nodo); // simple derecha
        }

        // FE = +2: el subárbol derecho es más alto
        if (fe > 1) {
            // Doble derecha-izquierda: hijo derecho con FE = -1
            if (factorEquilibrio(nodo.getDerecho()) < 0) {
                nodo.setDerecho(rotacionDerecha(nodo.getDerecho()));
            }
            return rotacionIzquierda(nodo); // simple izquierda
        }

        return nodo; // ya está balanceado
    }

//mostrarInOrden(): 
    public String mostrarInOrden() { // metodo "Publico"
        StringBuilder sb = new StringBuilder();
        inOrdenRec(raiz, sb);
        return sb.toString();
    }
    private void inOrdenRec(NodoAVL nodo, StringBuilder sb) { //"Recursiva"
        if (nodo == null) return;
        inOrdenRec(nodo.getIzquierdo(), sb);
        sb.append(nodo.getDato()).append("\n");
        inOrdenRec(nodo.getDerecho(), sb);
    }
    
// mostrarPreOrden(): 
    public String mostrarPreOrden() { // metodo "Publico"
        StringBuilder sb = new StringBuilder();
        preOrdenRec(raiz, sb);
        return sb.toString();
    }
    private void preOrdenRec(NodoAVL nodo, StringBuilder sb) { //"Recursiva"
        if (nodo == null) return;
        sb.append(nodo.getDato()).append("\n");
        preOrdenRec(nodo.getIzquierdo(), sb);
        preOrdenRec(nodo.getDerecho(), sb);
    }
    
//mostrarPostOrden(): 
    public String mostrarPostOrden() { // metodo "Publico"
        StringBuilder sb = new StringBuilder();
        postOrdenRec(raiz, sb);
        return sb.toString();
    }
    private void postOrdenRec(NodoAVL nodo, StringBuilder sb) { //"Recursiva"
        if (nodo == null) return;
        postOrdenRec(nodo.getIzquierdo(), sb);
        postOrdenRec(nodo.getDerecho(), sb);
        sb.append(nodo.getDato()).append("\n");
    }
    
//amplitud(): 
    public int amplitud() {
        if (raiz == null) return 0;
        NodoAVL[] cola = new NodoAVL[1000];
        int frente = 0, fin = 0;
        cola[fin++] = raiz;
        int maxNodos = 0;

        while (frente < fin) {
            int nodosNivel = fin - frente;
            maxNodos = Math.max(maxNodos, nodosNivel);
            int finNivel = fin;
            while (frente < finNivel) {
                NodoAVL actual = cola[frente++];
                if (actual.getIzquierdo() != null) cola[fin++] = actual.getIzquierdo();
                if (actual.getDerecho() != null) cola[fin++] = actual.getDerecho();
            }
        }
        return maxNodos;
    }
    
//profundidad():
     public int profundidad() { // metodo "Publico"
        return obtenerAltura(raiz);
    }

//destruirArbol(): 
    public void destruirArbol() {
        raiz = null;
    }
    
//metodo para contar los nodos
    public int contarNodos() { // metodo "Publico"
        return contarRec(raiz);
    }
    private int contarRec(NodoAVL nodo) { //"Recursiva"
        if (nodo == null) {
            return 0;
        }
        return 1 + contarRec(nodo.getIzquierdo()) + contarRec(nodo.getDerecho());
    }

//Metodo para actualizar (no dice en la estructura pero en el inicio de las instrucciones si)
   public void actualizar(Integer id, Empleado nuevosDatos) { // metodo "Publico"
        if (id == null) {
            throw new IllegalArgumentException("ERROR: El ID no puede ser nulo.");
        }
        if (nuevosDatos == null) {
            throw new IllegalArgumentException("ERROR: Los datos del empleado no pueden ser nulos.");
        }
        if (raiz == null) {
            throw new IllegalArgumentException("ERROR: El árbol está vacío, no hay empleados que actualizar.");
        }
        if (buscar(id) == null) { // reutiliza buscar y se ahorra eso
            throw new IllegalArgumentException("ERROR: No se encontró empleado con ID " + id + ".");
        }
        if (!id.equals(nuevosDatos.getId())) {
            throw new IllegalArgumentException("ERROR: El ID no se puede modificar (es la clave del árbol).");
        }
        reemplazarDato(raiz, id, nuevosDatos);
    }
    private void reemplazarDato(NodoAVL nodo, Integer id, Empleado nuevos) { //"Recursiva"
        if (nodo == null) return;
        if (id.equals(nodo.getDato().getId())) {
            nodo.setDato(nuevos);
            return;
        }
        if (id < nodo.getDato().getId()) {
            reemplazarDato(nodo.getIzquierdo(), id, nuevos);
        } else {
            reemplazarDato(nodo.getDerecho(), id, nuevos);
        }
    } 
}//final
